# Manus 指南

本仓库包含 Manus AI 代理平台的指南和文档。

## 文章

- [Manus 介绍](posts/introduction-to-manus/zh-CN.mdx) - 全面介绍 Manus 及其功能。
- [如何使用 Manus](posts/how-to-use-manus/zh-CN.mdx) - 有效使用 Manus 的分步指南。
- [Manus 使用场景](posts/manus-use-cases/zh-CN.mdx) - 探索 Manus 的各种使用场景和应用。
- [Manus 与其他 AI 代理的比较](posts/manus-vs-other-ai-agents/zh-CN.mdx) - Manus 与其他 AI 代理平台的比较。
- [理解 Manus Replay](posts/understanding-manus-replay/zh-CN.mdx) - 深入了解 Manus Replay 功能。

## 语言

本指南提供多种语言版本：
- [英文](README.md)
- [中文](README.CN.md) 