# Curso Interativo Manus

Um curso interativo sobre o agente de IA Manus, desenvolvido com React e TailwindCSS, com sistema de navegação progressiva e quizzes interativos.

## Sobre o Projeto

Este projeto é um curso interativo completo sobre o Manus, um revolucionário agente de IA desenvolvido pela equipe Monica. O curso está estruturado em 5 módulos progressivos, cada um contendo aulas detalhadas e quizzes interativos para reforçar o aprendizado.

O website foi desenvolvido com React e TailwindCSS, apresentando um design moderno inspirado em plataformas como Netflix e Apple. O sistema de navegação progressiva permite que cada aula seja desbloqueada apenas após a conclusão da anterior, incentivando um aprendizado estruturado e completo.

## Estrutura do Curso

O curso está organizado em 5 módulos progressivos:

1. **Introdução ao Manus**
   - O que é o Manus?
   - Capacidades Fundamentais
   - O Diferencial do Manus

2. **Como Usar o Manus**
   - Primeiros Passos
   - A Arte da Descrição de Tarefas
   - Interagindo com o Manus

3. **Casos de Uso do Manus**
   - Desenvolvimento de Código
   - Análise de Dados
   - Criação de Conteúdo e Pesquisa

4. **Manus vs Outros Agentes de IA**
   - Panorama dos Agentes de IA
   - Análise Comparativa
   - Escolhendo o Agente Certo

5. **Entendendo o Recurso de Replay do Manus**
   - O Poder da Transparência
   - Utilizando o Replay Efetivamente
   - Aprendendo com o Manus

Cada módulo inclui um quiz interativo para testar o conhecimento adquirido.

## Funcionalidades

- **Sistema de Autenticação**: Simulação de login para demonstração
- **Dashboard Personalizado**: Mostra progresso e próximas aulas recomendadas
- **Navegação Progressiva**: Aulas são desbloqueadas após a conclusão das anteriores
- **Quizzes Interativos**: Teste de conhecimento ao final de cada módulo
- **Design Responsivo**: Compatível com dispositivos desktop e móveis
- **Conteúdo em Markdown**: Suporte a formatação rica para o conteúdo das aulas

## Tecnologias Utilizadas

- **React**: Biblioteca JavaScript para construção de interfaces
- **TypeScript**: Superset tipado de JavaScript
- **TailwindCSS**: Framework CSS utilitário
- **React Router**: Navegação entre páginas
- **Context API**: Gerenciamento de estado global
- **React Markdown**: Renderização de conteúdo em formato Markdown

## Como Executar o Projeto

### Pré-requisitos

- Node.js (versão 14 ou superior)
- npm ou yarn

### Instalação

1. Clone este repositório:
   ```bash
   git clone https://github.com/seu-usuario/curso-manus.git
   cd curso-manus
   ```

2. Instale as dependências:
   ```bash
   npm install
   # ou
   yarn install
   ```

3. Inicie o servidor de desenvolvimento:
   ```bash
   npm start
   # ou
   yarn start
   ```

4. Acesse o aplicativo em seu navegador:
   ```
   http://localhost:3000
   ```

## Estrutura do Projeto

```
manus-curso/
├── public/              # Arquivos públicos
├── src/                 # Código fonte
│   ├── components/      # Componentes React reutilizáveis
│   ├── contexts/        # Contextos React (UserContext, CourseContext)
│   ├── data/            # Dados do curso
│   ├── pages/           # Páginas da aplicação
│   ├── App.tsx          # Componente principal
│   ├── index.tsx        # Ponto de entrada
│   └── index.css        # Estilos globais e configuração do Tailwind
└── package.json         # Dependências e scripts
```

## Personalização

Você pode personalizar este projeto de várias maneiras:

- **Conteúdo do Curso**: Edite os arquivos em `src/data/moduleContents.tsx` para modificar o conteúdo das aulas
- **Estilos**: Ajuste as cores e estilos em `tailwind.config.js` e `src/index.css`
- **Funcionalidades**: Adicione novas funcionalidades como certificados, fórum de discussão, etc.

## Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## Agradecimentos

- Documentação original do Manus
- Equipe Monica pelo desenvolvimento do agente Manus
- Comunidade React e TailwindCSS pelos excelentes recursos
